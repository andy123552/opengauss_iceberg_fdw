# openGauss-Iceberg 类型转换与操作符对齐详细设计

## 1. 设计目标

实现 Iceberg FDW 中 openGauss、Iceberg、底层索引系统之间的数据类型转换和操作符语义对齐，首期支持：

- 整数族：openGauss `int2`/`int4`/`int8` <-> Iceberg `int`/`long`。
- `char`/字符串：openGauss `char(n)`/`varchar` <-> Iceberg `string`。
- `vector`：openGauss `vector(n)` <-> Iceberg `list<float>`，并对齐向量索引 metric。

设计重点是数据准确性，而不是尽可能多地下推。任何语义不确定的转换或操作符下推都必须退回本地 recheck。

## 2. 总体架构

新增 `type_adapter` 与 `operator_adapter` 两个 FDW 内部模块，位于 FDW 主流程和团队提供的 Iceberg/index/delta 接口之间。

```
openGauss planner/executor/DML
        |
        v
iceberg_fdw callbacks
        |
        +-- type_adapter
        |     - schema mapping
        |     - Datum <-> Iceberg value
        |     - Arrow <-> Datum
        |     - write value encoding
        |
        +-- operator_adapter
        |     - Expr/OpExpr recognition
        |     - predicate normalization
        |     - index capability matching
        |     - recheck policy
        |
        v
catalog_adapter / index_adapter / delta_adapter
        |
        v
Iceberg metadata, data files, indexes, delta writer
```

模块边界：

| 模块 | 输入 | 输出 |
| --- | --- | --- |
| `type_adapter` | openGauss `TupleDesc`、Iceberg schema、Datum/Arrow 值 | 转换后的 FDW 内部值、错误、recheck 标志 |
| `operator_adapter` | openGauss expr tree、type mapping、index capabilities | 标准 predicate、vector search request、local recheck quals |
| `index_adapter` | 标准 predicate/vector search request | 底层 Iceberg 索引查询 |
| `delta_adapter` | 标准 write row batch | Iceberg/delta 写入 |

## 3. 核心数据结构

### 3.1 类型描述

```c
typedef enum IcebergFdwLogicalType {
    ICEBERG_FDW_TYPE_INT16,
    ICEBERG_FDW_TYPE_INT32,
    ICEBERG_FDW_TYPE_INT64,
    ICEBERG_FDW_TYPE_STRING,
    ICEBERG_FDW_TYPE_VECTOR_FLOAT32
} IcebergFdwLogicalType;

typedef enum IcebergFdwCoercionPolicy {
    ICEBERG_FDW_COERCE_EXACT,
    ICEBERG_FDW_COERCE_RECHECK_REQUIRED,
    ICEBERG_FDW_COERCE_REJECT
} IcebergFdwCoercionPolicy;

typedef struct IcebergFdwTypeMapping {
    AttrNumber attnum;
    int iceberg_field_id;
    char *iceberg_name;

    Oid pg_type;
    int32 pg_typmod;
    Oid pg_collation;

    IcebergFdwLogicalType logical_type;
    int vector_dim;
    bool nullable;

    IcebergFdwCoercionPolicy read_policy;
    IcebergFdwCoercionPolicy write_policy;
    IcebergFdwCoercionPolicy predicate_policy;
} IcebergFdwTypeMapping;
```

设计要求：

- `iceberg_field_id` 是列身份主键。
- `attnum` 只用于 openGauss tuple slot 位置。
- `iceberg_name` 只用于日志、EXPLAIN 和兼容缺少 field id 的数据文件。
- `pg_typmod` 对 `vector(n)`、`char(n)`、`varchar(n)` 必须生效。
- `predicate_policy` 可比 `read_policy` 更保守。

### 3.2 标准值

```c
typedef struct IcebergFdwValue {
    IcebergFdwLogicalType type;
    bool is_null;
    union {
        int16 int16_value;
        int32 int32_value;
        int64 int64_value;
        struct {
            const char *data;
            int len;
        } string_value;
        struct {
            int dim;
            const float *values;
        } vector_value;
    } v;
} IcebergFdwValue;
```

约束：

- 字符串值用长度而不是 `\0` 结束判断。
- vector 元素必须是 float32，不能含 NaN/Inf。
- vector 不允许元素级 NULL。
- `is_null=true` 时 union 内容无效。

### 3.3 标准操作符

```c
typedef enum IcebergFdwOperator {
    ICEBERG_FDW_OP_EQ,
    ICEBERG_FDW_OP_NE,
    ICEBERG_FDW_OP_LT,
    ICEBERG_FDW_OP_LE,
    ICEBERG_FDW_OP_GT,
    ICEBERG_FDW_OP_GE,
    ICEBERG_FDW_OP_IS_NULL,
    ICEBERG_FDW_OP_IS_NOT_NULL,

    ICEBERG_FDW_OP_VECTOR_L2,
    ICEBERG_FDW_OP_VECTOR_DOT,
    ICEBERG_FDW_OP_VECTOR_COSINE,
    ICEBERG_FDW_OP_VECTOR_L1
} IcebergFdwOperator;

typedef enum IcebergFdwRecheckMode {
    ICEBERG_FDW_RECHECK_NONE,
    ICEBERG_FDW_RECHECK_LOCAL_QUAL,
    ICEBERG_FDW_RECHECK_REFINE_VECTOR
} IcebergFdwRecheckMode;
```

## 4. 类型映射策略

### 4.1 整数族

首期支持 openGauss `int2`、`int4`、`int8` 与 Iceberg `int`、`long` 的映射。

| openGauss | Iceberg | 读策略 | 写策略 | 谓词策略 |
| --- | --- | --- | --- | --- |
| `INT2OID` | `int` | Iceberg int32 读入后检查 int16 范围，用 `Int16GetDatum` | `DatumGetInt16` 后提升为 int32 写入 | 强下推，常量按 int32 编码 |
| `INT4OID` | `int` | `Int32GetDatum` | `DatumGetInt32` | 强下推 |
| `INT8OID` | `long` | `Int64GetDatum` | `DatumGetInt64` | 强下推 |
| `INT2OID` | `long` | Iceberg int64 读入后检查 int16 范围 | `DatumGetInt16` 后提升为 int64 写入 | 强下推，常量按 int64 编码 |
| `INT4OID` | `long` | Iceberg int64 读入后检查 int32 范围 | `DatumGetInt32` 后提升为 int64 写入 | 强下推，常量按 int64 编码 |

拒绝或受限场景：

- `INT8OID` -> Iceberg `int` 是范围收缩，默认拒绝。只有显式用户配置允许且每个值都在 int32 范围内时，DML 可转换；谓词默认不强下推。
- Iceberg `long` -> openGauss `int2`/`int4` 需要逐值范围检查。为避免扫描中途才失败，建表/映射阶段默认拒绝；若用户显式声明字段值域受控，可允许读写但仍保留范围错误。
- Iceberg `int` -> openGauss `int8` 是安全提升，可支持，但默认建议把 openGauss 外表列声明为 `int4` 以反映真实 Iceberg schema。

索引 predicate：

- `=`, `!=`, `<`, `<=`, `>`, `>=`, `IS NULL` 对精确匹配和安全提升场景可强下推。
- 常量类型不等于列类型时，先按 openGauss coercion 规则归一化，再按 Iceberg 目标类型编码。
- `int2` 映射 Iceberg `int` 时，索引端看到的是 int32；FDW 负责保证 openGauss 侧读回仍满足 int16。

### 4.2 char / 字符串

首期支持：

| openGauss 类型 | Iceberg 类型 | 读策略 | 写策略 | 谓词策略 |
| --- | --- | --- | --- | --- |
| `BPCHAROID` | `string` | 读入后按 openGauss `bpchar` typmod 规范化 | 写出 openGauss 语义值 | `=` 候选下推 + recheck |
| `VARCHAROID` | `string` | 按 typmod 校验 | 按 typmod 校验 | `=` 可配置强下推，默认 recheck |
| `CHAROID` | 不默认映射 | 拒绝 | 拒绝 | 拒绝 |

`bpchar` 处理：

- 读入 Iceberg `string` 后调用 openGauss 类型输入/typmod 路径或等价函数，保证长度和 blank padding 语义由 openGauss 决定。
- 写出 `bpchar` 时要明确是否保留尾部空格。建议保留 openGauss Datum 转文本后的语义值，不做额外 trim。
- `bpchar = const` 只作为 candidate predicate 下推，最终保留原 `OpExpr` 在本地执行器 recheck。

`varchar` 处理：

- 读入时超过 typmod 应报错，而不是截断。
- 写出时同样报错。
- 若 `attcollation` 是 binary/C 语义，且索引系统声明字符串比较也是字节序，可强下推 `=` 和范围谓词。
- 其他 collation 默认候选下推或不下推。

编码策略：

- FDW 内部标准字符串统一 UTF-8。
- openGauss 数据库编码为 UTF-8 时直接传递。
- 非 UTF-8 数据库编码首期拒绝字符串索引强下推；读写可以通过编码转换函数实现后再打开。

### 4.3 vector

首期映射：

| openGauss | Iceberg | Arrow/Parquet 建议 | 约束 |
| --- | --- | --- | --- |
| `vector(n)` | `list<float>` | FixedSizeList<Float32> 优先 | 维度必须等于 `n` |
| `vector` 无 typmod | `list<float>` | List<Float32> | 读首批后可缓存维度；索引列必须有固定维度 |

列级 metadata 建议：

```text
iceberg.field.<field-id>.logical_type = vector
iceberg.field.<field-id>.vector.dimension = N
iceberg.field.<field-id>.vector.element_type = float32
iceberg.field.<field-id>.vector.metric.default = l2
```

读入规则：

1. Iceberg/Arrow 值为 NULL：openGauss 值为 NULL。
2. list 元素类型必须为 float32；float64 首期拒绝，避免精度变化。
3. list 不允许 null element。
4. 维度必须大于 0 且不超过 `VECTOR_MAX_DIM=16000`。
5. 若 openGauss typmod 指定维度，实际维度必须相等。
6. 元素必须有限，拒绝 NaN/Inf。
7. 分配 openGauss `Vector` varlena，并用 float32 填充。

写出规则：

1. detoast `Datum` 为 `Vector*`。
2. 读取 `dim` 和 `x[]`。
3. 按 Iceberg field id 写为 `list<float>`。
4. 同样校验维度和有限性。

## 5. 操作符识别与下推

### 5.1 planner 输入形态

`operator_adapter` 需要识别：

- `RestrictInfo` 中的 `OpExpr`。
- `NullTest`。
- `ScalarArrayOpExpr`，后续可支持 `IN`，首期可拒绝。
- `SortGroupClause`/pathkeys 中的 vector distance order by。
- `Limit`，vector top-k 必须有 LIMIT 才下推为 ANN/top-k。

### 5.2 标量谓词矩阵

| 类型 | 操作符 | 下推级别 | 本地 recheck |
| --- | --- | --- | --- |
| int/long | `=` | 强下推 | 否 |
| int/long | `<`, `<=`, `>`, `>=` | 强下推 | 否 |
| int/long | `!=` | 强下推或残差 | 建议是，取决于索引能力 |
| int/long | `IS NULL` | 强下推 | 否 |
| varchar | `=` | 默认候选下推 | 是 |
| varchar | 范围 | 默认不下推 | 是 |
| bpchar | `=` | 候选下推 | 是 |
| bpchar | 范围 | 不下推 | 是 |

强下推的前提：

- 常量类型与列类型经过 openGauss coercion 后确定。
- 操作符 OID 与类型 OID 在白名单中。
- 对应 Iceberg/index 类型完全匹配。
- collation 和比较语义一致。

### 5.3 vector top-k 矩阵

| SQL | openGauss 函数 | 索引 metric | 排序语义 | 下推条件 |
| --- | --- | --- | --- | --- |
| `ORDER BY v <-> q LIMIT k` | `l2_distance` | `l2` | distance ASC | 可下推 |
| `ORDER BY v <#> q LIMIT k` | `negative_inner_product` | `dot` / `inner_product` | similarity DESC 等价于 negative ASC | 可下推 |
| `ORDER BY v <=> q LIMIT k` | `cosine_distance` | `cosine` | distance ASC | 非零向量可下推 |
| `ORDER BY v <+> q LIMIT k` | `l1_distance` | `l1` | distance ASC | 索引声明支持才下推 |

请求结构建议：

```c
typedef struct IcebergFdwVectorSearch {
    int field_id;
    IcebergFdwOperator metric;
    IcebergFdwValue query_vector;
    int limit;
    bool approximate_ok;
    IcebergFdwRecheckMode recheck_mode;
    List *prefilter_predicates;
    List *postfilter_quals;
} IcebergFdwVectorSearch;
```

规则：

- vector top-k 必须携带 `LIMIT`；无 LIMIT 时不下推 ANN，只保留普通排序。
- 查询向量必须是常量或 stable 参数，可在执行期绑定。
- 查询向量维度必须与列维度一致。
- `cosine` 查询向量不能是零向量；索引系统也必须声明如何处理存量零向量。
- 如果索引返回近似结果，EXPLAIN 必须显示 approximate/refine 状态。
- 如果标量谓词不能 prefilter，则作为 postfilter/local qual；top-k 的正确性会受 postfilter 影响，必须在 EXPLAIN 中标出。

### 5.4 操作符白名单

实现时维护一张静态/动态白名单。静态表用于首期快速落地，动态校验用于防止 OID 变化。

```c
typedef struct IcebergFdwOperatorRule {
    Oid left_type;
    Oid right_type;
    const char *operator_name;
    IcebergFdwOperator op;
    bool requires_binary_collation;
    bool supports_index_exact;
    bool requires_recheck;
} IcebergFdwOperatorRule;
```

启动或首次使用时通过系统缓存校验：

- `OpernameGetOprid` 找 operator OID。
- `pg_operator` 校验左右类型和 `oprcode`。
- `pg_opclass`/`pg_opfamily` 校验索引 metric 与 opclass 名称。

不要只靠字符串匹配 `<->`、`=`。

## 6. 转换 API 设计

### 6.1 初始化 schema mapping

```c
List *iceberg_type_build_mappings(Relation rel, const IcebergSchema *schema);
```

职责：

- 遍历 openGauss foreign table `TupleDesc`。
- 根据 table options 或 catalog adapter 找 Iceberg field id。
- 读取 `pg_type` 元数据。
- 校验 Iceberg 类型兼容性。
- 为每列生成 `IcebergFdwTypeMapping`。

失败示例：

- openGauss `int8` 对应 Iceberg `int`：默认报错，避免范围收缩。
- openGauss `int4` 对应 Iceberg `long`：允许安全提升，但读回时检查 int32 范围。
- openGauss `vector(768)` 对应 Iceberg `list<double>`：报错。
- openGauss `bpchar(10)` 对应 Iceberg `string`：允许，但 predicate recheck。

### 6.2 Iceberg/Arrow 到 Datum

```c
Datum iceberg_type_to_datum(
    const IcebergFdwTypeMapping *mapping,
    const IcebergFdwValue *value,
    bool *isnull);
```

实现：

- `INT16`：检查范围后 `Int16GetDatum(value->v.int16_value)`。
- `INT32`：`Int32GetDatum(value->v.int32_value)`。
- `INT64`：`Int64GetDatum(value->v.int64_value)`。
- `STRING`：调用 openGauss 字符类型输入函数，传入 `pg_typmod` 和 collation。
- `VECTOR_FLOAT32`：分配 `Vector`，设置 varlena size、`dim`、`x[]`。

内存：

- 返回的 varlena 必须在当前 per-tuple 或 batch memory context 中。
- batch 完成后统一释放。

### 6.3 Datum 到 Iceberg/Index 值

```c
bool iceberg_datum_to_value(
    const IcebergFdwTypeMapping *mapping,
    Datum datum,
    bool isnull,
    IcebergFdwValue *out,
    char **error);
```

用途：

- DML 写入。
- 常量 predicate 下推。
- vector query 参数绑定。

规则：

- NULL 直接设置 `out->is_null=true`。
- 字符串必须使用 openGauss 输出函数或类型专用函数，避免绕过 typmod/collation 语义。
- vector 通过 `DatumGetVector` detoast，复制为索引系统可持有的 float32 buffer。

### 6.4 Predicate 编码

```c
typedef struct IcebergFdwPredicate {
    int field_id;
    IcebergFdwOperator op;
    IcebergFdwValue value;
    IcebergFdwRecheckMode recheck;
} IcebergFdwPredicate;
```

向 index adapter 输出时必须包含：

- field id。
- logical type。
- operator。
- value。
- recheck mode。
- collation policy。

## 7. 索引能力协商

index adapter 需要暴露能力声明：

```c
typedef struct IcebergIndexTypeCapability {
    IcebergFdwLogicalType type;
    bool supports_eq;
    bool supports_range;
    bool supports_is_null;
    bool supports_vector_l2;
    bool supports_vector_dot;
    bool supports_vector_cosine;
    bool supports_vector_l1;
    bool exact;
    bool supports_prefilter;
    bool supports_postfilter;
    bool returns_distance;
    bool returns_similarity;
} IcebergIndexTypeCapability;
```

规划阶段决策：

1. 根据列类型和 operator 找到标准 predicate。
2. 查 index capability。
3. 若能力 exact 且语义一致，生成 index path 且不 recheck。
4. 若能力 candidate only，生成 index path 并保留 local qual。
5. 若能力不支持，不下推。

## 8. DML 转换策略

### 8.1 INSERT

- 对每个目标列按 field id 编码。
- openGauss 缺省值先由执行器形成 slot，FDW 只读 slot。
- vector/list 字段写入前完整校验。
- 字符串长度错误在 FDW 写出前报错。

### 8.2 UPDATE

- old row locator 由 scan/index 返回，不由类型转换模块推断。
- 新值按 INSERT 同样转换。
- 如果更新 vector 维度与列定义不一致，拒绝。
- 如果更新 char/varchar 超 typmod，拒绝。

### 8.3 DELETE

- 类型转换只参与 old row locator 中业务 key/equality delete 的值编码。
- 若 equality delete 依赖字符串 key，必须记录 collation/recheck 风险；首期优先 position delete。

## 9. 测试计划

### 9.1 整数族

- `int2` 正负边界：`-32768`、`32767`。
- `int4` 正负边界：`-2147483648`、`2147483647`。
- `int8` 正负边界：`-9223372036854775808`、`9223372036854775807`。
- Iceberg `int` <-> openGauss `int2`/`int4`。
- Iceberg `long` <-> openGauss `int8`。
- openGauss `int2`/`int4` 安全提升到 Iceberg `long`。
- openGauss `int8` 映射 Iceberg `int` 默认报错。
- Iceberg `long` 读入 openGauss `int2`/`int4` 超范围报错。
- `=`, `<`, `<=`, `>`, `>=`, `IS NULL` 下推。
- DML 写入后读回一致。

### 9.2 char / 字符串

- `varchar(3)` 读入超长报错。
- `char(3)` 读入/写出尾部空格行为与 openGauss 本地表一致。
- `bpchar = const` 保留 local recheck。
- 非 binary collation 下范围谓词不强下推。
- NULL 与空字符串区分。

### 9.3 vector

- `vector(3)` 读写 `[1,2,3]`。
- 维度不一致报错。
- 空 vector、NaN、Inf 报错。
- list element null 报错。
- `<->`、`<#>`、`<=>` 识别为不同 metric。
- `ORDER BY v <-> q LIMIT k` 生成 vector search request。
- 无 LIMIT 的 vector order by 不下推 ANN。
- cosine 零向量拒绝下推。

### 9.4 recheck

- 字符串候选下推后，本地 recheck 能过滤掉语义不一致结果。
- ANN 近似结果 explain 标明 approximate。
- postfilter 场景 explain 标明 top-k 可能先取候选再过滤。

## 10. 分阶段落地

### Phase 1: 类型映射基础

- 新增 `type_adapter` 文件。
- 实现 `INT2OID`、`INT4OID`、`INT8OID`、`BPCHAROID`、`VARCHAROID`、`VECTOROID` mapping。
- 实现 `IcebergFdwValue`。
- 实现读路径 Datum 构造。

### Phase 2: 谓词识别

- 新增 `operator_adapter` 文件。
- 识别 int 标量谓词。
- 识别字符串等值候选下推。
- 识别 vector top-k pathkey。

### Phase 3: index adapter 对接

- 定义 index capability。
- 将 predicate/vector search request 传给团队索引接口。
- explain 输出下推、recheck、metric、limit。

### Phase 4: DML 转换

- 插入/更新值编码。
- vector 写入校验。
- 字符串 typmod 校验。
- 错误路径测试。

## 11. 待确认问题

- 团队 Iceberg catalog 是否已为 vector 列记录固定维度和 logical type。
- 底层索引接口是否接收 `list<float>` 原值，还是要求独立 vector binary layout。
- 索引系统中 dot metric 返回的是相似度、内积距离，还是 openGauss 风格负内积。
- 字符串索引比较是否为 UTF-8 binary order。
- 是否需要首期支持 `text`。
- 是否允许 `vector` 无 typmod 建索引。
- DML 写入是否允许 Iceberg `list<double>` 自动降为 float32。

## 12. 准确性默认值

首期默认策略：

- 整数族精确匹配和安全提升强下推；范围收缩默认拒绝。
- varchar/bpchar 读写支持，谓词默认 recheck。
- vector 只支持 `list<float>`，必须固定维度才能建索引。
- vector top-k 支持 l2/dot/cosine，l1 等索引系统声明后再打开。
- 所有未明确支持的类型、操作符和隐式 cast 都拒绝下推。
